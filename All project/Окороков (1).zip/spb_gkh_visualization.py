# Визуализация типовых запросов для проекта "ЖКХ, СПб"
# Формат: Python + PostgreSQL + pandas + matplotlib
#
# Перед запуском:
# 1. Установить библиотеки:
#    pip install pandas matplotlib sqlalchemy psycopg2-binary
#
# 2. Вписать свой индивидуальный номер ИСУ:
#    ISU_NUMBER = "123456"
#
# 3. Убедиться, что таблицы уже созданы и заполнены SQL DDL/DML-скриптами.

import pandas as pd
import matplotlib.pyplot as plt
from sqlalchemy import create_engine


# ============================================================
# 1. Параметры подключения к PostgreSQL PRO
# ============================================================

ISU_NUMBER = "XXXXXX"  # замени на свой номер ИСУ

DB_USER = f"bk_{ISU_NUMBER}_2026"
DB_PASSWORD = f"bk_{ISU_NUMBER}"
DB_HOST = "postgrepro.dc-edu.ru"
DB_PORT = 5432
DB_NAME = "dbstud"
SCHEMA_NAME = DB_USER

connection_url = (
    f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}"
    f"@{DB_HOST}:{DB_PORT}/{DB_NAME}"
)

engine = create_engine(connection_url)


def read_query(sql: str) -> pd.DataFrame:
    """Выполнить SQL-запрос и вернуть результат в DataFrame."""
    return pd.read_sql(sql, engine)


# ============================================================
# 2. SQL-запросы для визуализации
# ============================================================

# Запрос 1: количество заявок по статусам
query_task_status = f"""
SELECT
    task_status,
    COUNT(*) AS tasks_count
FROM {SCHEMA_NAME}.tasks
GROUP BY task_status
ORDER BY tasks_count DESC;
"""

# Запрос 2: количество заявок по классам сервисных функций
query_tasks_by_class = f"""
SELECT
    sc.class_name,
    COUNT(t.task_id) AS tasks_count
FROM {SCHEMA_NAME}.tasks t
JOIN {SCHEMA_NAME}.service_types st
    ON st.service_type_id = t.service_type_id
JOIN {SCHEMA_NAME}.service_classes sc
    ON sc.class_id = st.class_id
GROUP BY sc.class_name
ORDER BY tasks_count DESC;
"""

# Запрос 3: TOP специалистов по количеству выполненных заявок
query_top_specialists = f"""
SELECT
    s.full_name,
    sc.class_name,
    COUNT(t.task_id) AS completed_tasks
FROM {SCHEMA_NAME}.tasks t
JOIN {SCHEMA_NAME}.staff s
    ON s.staff_id = t.assigned_staff_id
JOIN {SCHEMA_NAME}.service_classes sc
    ON sc.class_id = s.class_id
WHERE t.task_status = 'done'
GROUP BY s.full_name, sc.class_name
ORDER BY completed_tasks DESC
LIMIT 10;
"""

# Запрос 4: средняя этажность зданий по улицам
query_avg_levels_by_street = f"""
SELECT
    street,
    COUNT(*) AS buildings_count,
    ROUND(AVG(levels)::numeric, 2) AS avg_levels
FROM {SCHEMA_NAME}.buildings
WHERE street IS NOT NULL
  AND street <> 'Unknown'
  AND levels IS NOT NULL
GROUP BY street
HAVING COUNT(*) >= 3
ORDER BY avg_levels DESC, buildings_count DESC
LIMIT 10;
"""

# Запрос 5: количество сервисных функций зданий по статусам
query_service_status = f"""
SELECT
    service_status,
    COUNT(*) AS services_count
FROM {SCHEMA_NAME}.building_services
GROUP BY service_status
ORDER BY services_count DESC;
"""


# ============================================================
# 3. Получение данных из БД
# ============================================================

df_task_status = read_query(query_task_status)
df_tasks_by_class = read_query(query_tasks_by_class)
df_top_specialists = read_query(query_top_specialists)
df_avg_levels_by_street = read_query(query_avg_levels_by_street)
df_service_status = read_query(query_service_status)


# ============================================================
# 4. Визуализация результатов запросов
# ============================================================

# Диаграмма 1: столбчатая диаграмма по статусам заявок
plt.figure(figsize=(8, 5))
plt.bar(df_task_status["task_status"], df_task_status["tasks_count"])
plt.title("Количество заявок по статусам")
plt.xlabel("Статус заявки")
plt.ylabel("Количество заявок")
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig("chart_1_task_status.png", dpi=300)
plt.show()


# Диаграмма 2: круговая диаграмма заявок по классам сервисов
plt.figure(figsize=(7, 7))
plt.pie(
    df_tasks_by_class["tasks_count"],
    labels=df_tasks_by_class["class_name"],
    autopct="%1.1f%%",
    startangle=90
)
plt.title("Доля заявок по классам сервисных функций")
plt.tight_layout()
plt.savefig("chart_2_tasks_by_class.png", dpi=300)
plt.show()


# Диаграмма 3: горизонтальная столбчатая диаграмма TOP специалистов
plt.figure(figsize=(10, 6))
plt.barh(df_top_specialists["full_name"], df_top_specialists["completed_tasks"])
plt.title("TOP-10 специалистов по количеству выполненных заявок")
plt.xlabel("Количество выполненных заявок")
plt.ylabel("Специалист")
plt.gca().invert_yaxis()
plt.tight_layout()
plt.savefig("chart_3_top_specialists.png", dpi=300)
plt.show()


# Диаграмма 4: линейный график средней этажности по улицам
plt.figure(figsize=(10, 5))
plt.plot(
    df_avg_levels_by_street["street"],
    df_avg_levels_by_street["avg_levels"],
    marker="o"
)
plt.title("Средняя этажность зданий по улицам")
plt.xlabel("Улица")
plt.ylabel("Средняя этажность")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.savefig("chart_4_avg_levels_by_street.png", dpi=300)
plt.show()


# Диаграмма 5: столбчатая диаграмма статусов сервисных функций зданий
plt.figure(figsize=(8, 5))
plt.bar(df_service_status["service_status"], df_service_status["services_count"])
plt.title("Количество сервисных функций зданий по статусам")
plt.xlabel("Статус сервисной функции")
plt.ylabel("Количество")
plt.tight_layout()
plt.savefig("chart_5_service_status.png", dpi=300)
plt.show()


# ============================================================
# 5. Вывод результатов в консоль
# ============================================================

print("1. Количество заявок по статусам:")
print(df_task_status)

print("\\n2. Количество заявок по классам сервисных функций:")
print(df_tasks_by_class)

print("\\n3. TOP специалистов:")
print(df_top_specialists)

print("\\n4. Средняя этажность по улицам:")
print(df_avg_levels_by_street)

print("\\n5. Статусы сервисных функций зданий:")
print(df_service_status)
