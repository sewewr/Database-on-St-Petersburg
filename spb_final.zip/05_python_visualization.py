# Визуализация типовых SQL-запросов для проекта "ЖКХ, СПб"
# Код подключается к уже созданной и заполненной базе PostgreSQL PRO.
#
# Перед запуском:
# pip install pandas matplotlib sqlalchemy psycopg2-binary

import pandas as pd
import matplotlib.pyplot as plt
from sqlalchemy import create_engine


DB_USER = "bk_504518_2026"
DB_PASSWORD = "bk_504518"
DB_HOST = "postgrepro.dc-edu.ru"
DB_PORT = 5432
DB_NAME = "dbstud"
SCHEMA_NAME = "bk_504518_2026"

connection_url = (
    f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}"
    f"@{DB_HOST}:{DB_PORT}/{DB_NAME}"
)

engine = create_engine(
    connection_url,
    connect_args={"sslmode": "require"}
)


def read_query(sql: str) -> pd.DataFrame:
    return pd.read_sql(sql, engine)


check_tables_query = f"""
SELECT table_name
FROM information_schema.tables
WHERE table_schema = '{SCHEMA_NAME}'
ORDER BY table_name;
"""

tables_df = read_query(check_tables_query)
print("Таблицы в схеме:")
print(tables_df)

required_tables = {
    "buildings",
    "premises",
    "service_classes",
    "service_types",
    "building_services",
    "staff",
    "tasks",
    "staff_schedule",
    "task_statuses",
    "service_statuses"
}

existing_tables = set(tables_df["table_name"].tolist())
missing_tables = required_tables - existing_tables

if missing_tables:
    raise Exception(
        "В базе не найдены нужные таблицы: "
        + ", ".join(sorted(missing_tables))
        + ". Сначала выполни DDL-скрипт и DML-скрипт."
    )


query_task_status = f"""
SELECT
    ts.status_name AS task_status,
    COUNT(*) AS tasks_count
FROM {SCHEMA_NAME}.tasks t
JOIN {SCHEMA_NAME}.task_statuses ts
    ON ts.task_status_id = t.task_status_id
GROUP BY ts.status_name
ORDER BY tasks_count DESC;
"""

query_tasks_by_class = f"""
SELECT
    sc.class_name,
    COUNT(t.task_id) AS tasks_count
FROM {SCHEMA_NAME}.tasks t
JOIN {SCHEMA_NAME}.service_types st
    ON st.service_type_id = t.service_type_id
JOIN {SCHEMA_NAME}.service_classes sc
    ON sc.class_id = st.class_id
GROUP BY sc.class_name
ORDER BY tasks_count DESC;
"""

query_top_specialists = f"""
SELECT
    s.full_name,
    sc.class_name,
    COUNT(t.task_id) AS completed_tasks
FROM {SCHEMA_NAME}.tasks t
JOIN {SCHEMA_NAME}.task_statuses ts
    ON ts.task_status_id = t.task_status_id
JOIN {SCHEMA_NAME}.staff s
    ON s.staff_id = t.assigned_staff_id
JOIN {SCHEMA_NAME}.service_classes sc
    ON sc.class_id = s.class_id
WHERE ts.status_code = 'done'
GROUP BY s.full_name, sc.class_name
ORDER BY completed_tasks DESC
LIMIT 10;
"""

query_avg_levels_by_street = f"""
SELECT
    street,
    COUNT(*) AS buildings_count,
    ROUND(AVG(levels)::numeric, 2) AS avg_levels
FROM {SCHEMA_NAME}.buildings
WHERE street IS NOT NULL
  AND street <> 'Unknown'
  AND levels IS NOT NULL
GROUP BY street
HAVING COUNT(*) >= 3
ORDER BY avg_levels DESC, buildings_count DESC
LIMIT 10;
"""

query_service_status = f"""
SELECT
    ss.status_name AS service_status,
    COUNT(*) AS services_count
FROM {SCHEMA_NAME}.building_services bs
JOIN {SCHEMA_NAME}.service_statuses ss
    ON ss.service_status_id = bs.service_status_id
GROUP BY ss.status_name
ORDER BY services_count DESC;
"""


df_task_status = read_query(query_task_status)
df_tasks_by_class = read_query(query_tasks_by_class)
df_top_specialists = read_query(query_top_specialists)
df_avg_levels_by_street = read_query(query_avg_levels_by_street)
df_service_status = read_query(query_service_status)


plt.figure(figsize=(8, 5))
bars = plt.barh(df_task_status["task_status"], df_task_status["tasks_count"])
plt.title("Количество заявок по статусам")
plt.xlabel("Количество заявок")
plt.ylabel("Статус заявки")
for bar in bars:
    width = bar.get_width()
    plt.text(width + max(df_task_status["tasks_count"]) * 0.01, bar.get_y() + bar.get_height()/2, str(int(width)), va="center")
plt.tight_layout()
plt.savefig("chart_1_task_status_ru.png", dpi=300)
plt.show()


plt.figure(figsize=(7, 7))
plt.pie(
    df_tasks_by_class["tasks_count"],
    labels=df_tasks_by_class["class_name"],
    autopct="%1.1f%%",
    startangle=90,
)
plt.title("Доля заявок по классам сервисных функций")
plt.tight_layout()
plt.savefig("chart_2_tasks_by_class_ru.png", dpi=300)
plt.show()


plt.figure(figsize=(10, 6))
bars = plt.barh(df_top_specialists["full_name"], df_top_specialists["completed_tasks"])
plt.title("TOP-10 специалистов по количеству выполненных заявок")
plt.xlabel("Количество выполненных заявок")
plt.ylabel("Специалист")
plt.gca().invert_yaxis()
for bar in bars:
    width = bar.get_width()
    plt.text(width + max(df_top_specialists["completed_tasks"]) * 0.01, bar.get_y() + bar.get_height()/2, str(int(width)), va="center")
plt.tight_layout()
plt.savefig("chart_3_top_specialists_ru.png", dpi=300)
plt.show()


plt.figure(figsize=(10, 5))
plt.plot(
    df_avg_levels_by_street["street"],
    df_avg_levels_by_street["avg_levels"],
    marker="o",
)
plt.title("Средняя этажность зданий по улицам")
plt.xlabel("Улица")
plt.ylabel("Средняя этажность")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.savefig("chart_4_avg_levels_by_street_ru.png", dpi=300)
plt.show()


plt.figure(figsize=(8, 5))
bars = plt.barh(df_service_status["service_status"], df_service_status["services_count"])
plt.title("Количество сервисных функций зданий по статусам")
plt.xlabel("Количество сервисных функций")
plt.ylabel("Статус сервисной функции")
for bar in bars:
    width = bar.get_width()
    plt.text(width + max(df_service_status["services_count"]) * 0.01, bar.get_y() + bar.get_height()/2, str(int(width)), va="center")
plt.tight_layout()
plt.savefig("chart_5_service_status_ru.png", dpi=300)
plt.show()


print("\n1. Количество заявок по статусам:")
print(df_task_status)

print("\n2. Количество заявок по классам сервисных функций:")
print(df_tasks_by_class)

print("\n3. TOP специалистов:")
print(df_top_specialists)

print("\n4. Средняя этажность по улицам:")
print(df_avg_levels_by_street)

print("\n5. Статусы сервисных функций зданий:")
print(df_service_status)

print("\nГотово. Диаграммы сохранены в PNG-файлы.")
