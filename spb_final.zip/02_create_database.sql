SET search_path TO bk_504518_2026;

DROP VIEW IF EXISTS v_task_details;
DROP TABLE IF EXISTS staff_schedule, tasks, building_services, staff, service_types, service_classes, premises, buildings, premise_types, service_statuses, task_statuses, work_areas CASCADE;

CREATE TABLE buildings (
    building_id BIGSERIAL PRIMARY KEY,
    osm_id BIGINT UNIQUE,
    object_type VARCHAR(20),
    building_type VARCHAR(100) NOT NULL,
    street TEXT,
    house_number VARCHAR(50),
    address_full TEXT,
    city VARCHAR(100) DEFAULT 'Санкт-Петербург',
    levels INTEGER,
    lat DOUBLE PRECISION NOT NULL,
    lon DOUBLE PRECISION NOT NULL,
    source_name VARCHAR(100) DEFAULT 'OpenStreetMap',
    CONSTRAINT chk_buildings_levels_positive CHECK (levels IS NULL OR levels > 0),
    CONSTRAINT chk_buildings_coordinates CHECK (lat BETWEEN -90 AND 90 AND lon BETWEEN -180 AND 180)
);

CREATE TABLE premise_types (
    premise_type_id SMALLSERIAL PRIMARY KEY,
    type_code VARCHAR(50) NOT NULL UNIQUE,
    type_name VARCHAR(100) NOT NULL
);

CREATE TABLE premises (
    premise_id BIGSERIAL PRIMARY KEY,
    building_id BIGINT NOT NULL REFERENCES buildings(building_id) ON DELETE CASCADE,
    premise_type_id SMALLINT NOT NULL REFERENCES premise_types(premise_type_id) ON DELETE RESTRICT,
    premise_number VARCHAR(30),
    area_m2 NUMERIC(10,2),
    floor INTEGER,
    is_residential BOOLEAN DEFAULT TRUE,
    description TEXT,
    CONSTRAINT chk_premises_area_positive CHECK (area_m2 IS NULL OR area_m2 > 0)
);

CREATE TABLE service_classes (
    class_id SMALLSERIAL PRIMARY KEY,
    class_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE service_types (
    service_type_id SMALLSERIAL PRIMARY KEY,
    class_id SMALLINT NOT NULL REFERENCES service_classes(class_id) ON DELETE RESTRICT,
    service_name VARCHAR(150) NOT NULL,
    priority_level INTEGER DEFAULT 1,
    description TEXT,
    CONSTRAINT chk_service_priority CHECK (priority_level BETWEEN 1 AND 5),
    CONSTRAINT uq_service_name_class UNIQUE (class_id, service_name)
);

CREATE TABLE service_statuses (
    service_status_id SMALLSERIAL PRIMARY KEY,
    status_code VARCHAR(50) NOT NULL UNIQUE,
    status_name VARCHAR(100) NOT NULL
);

CREATE TABLE building_services (
    building_service_id BIGSERIAL PRIMARY KEY,
    building_id BIGINT NOT NULL REFERENCES buildings(building_id) ON DELETE CASCADE,
    service_type_id SMALLINT NOT NULL REFERENCES service_types(service_type_id) ON DELETE RESTRICT,
    service_status_id SMALLINT NOT NULL REFERENCES service_statuses(service_status_id) ON DELETE RESTRICT,
    installed_at DATE,
    last_check_at DATE,
    comment TEXT,
    CONSTRAINT uq_building_service UNIQUE (building_id, service_type_id)
);

CREATE TABLE work_areas (
    work_area_id SMALLSERIAL PRIMARY KEY,
    area_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE staff (
    staff_id BIGSERIAL PRIMARY KEY,
    class_id SMALLINT NOT NULL REFERENCES service_classes(class_id) ON DELETE RESTRICT,
    work_area_id SMALLINT REFERENCES work_areas(work_area_id) ON DELETE SET NULL,
    full_name VARCHAR(150) NOT NULL,
    phone VARCHAR(30),
    qualification VARCHAR(100),
    rating NUMERIC(3,2) DEFAULT 0,
    is_available BOOLEAN DEFAULT TRUE,
    CONSTRAINT chk_staff_rating CHECK (rating BETWEEN 0 AND 5)
);

CREATE TABLE task_statuses (
    task_status_id SMALLSERIAL PRIMARY KEY,
    status_code VARCHAR(50) NOT NULL UNIQUE,
    status_name VARCHAR(100) NOT NULL
);

CREATE TABLE tasks (
    task_id BIGSERIAL PRIMARY KEY,
    building_id BIGINT NOT NULL REFERENCES buildings(building_id) ON DELETE CASCADE,
    premise_id BIGINT REFERENCES premises(premise_id) ON DELETE SET NULL,
    service_type_id SMALLINT NOT NULL REFERENCES service_types(service_type_id) ON DELETE RESTRICT,
    assigned_staff_id BIGINT REFERENCES staff(staff_id) ON DELETE SET NULL,
    task_status_id SMALLINT NOT NULL REFERENCES task_statuses(task_status_id) ON DELETE RESTRICT,
    task_description TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    due_at TIMESTAMP NOT NULL,
    completed_at TIMESTAMP,
    priority INTEGER DEFAULT 3,
    CONSTRAINT chk_task_priority CHECK (priority BETWEEN 1 AND 5),
    CONSTRAINT chk_task_dates CHECK (due_at >= created_at AND (completed_at IS NULL OR completed_at >= created_at))
);

CREATE TABLE staff_schedule (
    schedule_id BIGSERIAL PRIMARY KEY,
    staff_id BIGINT NOT NULL REFERENCES staff(staff_id) ON DELETE CASCADE,
    work_date DATE NOT NULL,
    time_from TIME NOT NULL,
    time_to TIME NOT NULL,
    is_busy BOOLEAN DEFAULT FALSE,
    CONSTRAINT chk_schedule_time CHECK (time_to > time_from),
    CONSTRAINT uq_staff_schedule_slot UNIQUE (staff_id, work_date, time_from, time_to)
);

CREATE INDEX idx_buildings_street ON buildings(street);
CREATE INDEX idx_buildings_coordinates ON buildings(lat, lon);
CREATE INDEX idx_premises_building_id ON premises(building_id);
CREATE INDEX idx_service_types_class_id ON service_types(class_id);
CREATE INDEX idx_building_services_building_id ON building_services(building_id);
CREATE INDEX idx_staff_class_id ON staff(class_id);
CREATE INDEX idx_tasks_building_id ON tasks(building_id);
CREATE INDEX idx_tasks_service_type_id ON tasks(service_type_id);
CREATE INDEX idx_tasks_assigned_staff_id ON tasks(assigned_staff_id);
CREATE INDEX idx_tasks_due ON tasks(due_at);
CREATE INDEX idx_staff_schedule_staff_date ON staff_schedule(staff_id, work_date);
